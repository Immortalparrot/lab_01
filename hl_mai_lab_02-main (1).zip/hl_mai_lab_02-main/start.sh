export DB_HOST=127.0.0.1
export DB_PORT=3360
export DB_LOGIN=stud
export DB_PASSWORD=stud
export DB_DATABASE=archdb

./build/trip_api

